package com.reusoil.app.services.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.repository.empresa.EmpresaRepository;
import org.apache.el.stream.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmpresaService {

    final private EmpresaRepository empresaRepository;

    public EmpresaService(EmpresaRepository empresaRepository){
        this.empresaRepository = empresaRepository;
    }

    @Transactional(readOnly = true)
    public List<EmpresaEntity> findAll() {
        return empresaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional findById(Long id) {
        return empresaRepository.findById(id);
    }

    @Transactional
    public EmpresaEntity save(EmpresaEntity empresa) {
        return empresaRepository.save(empresa);
    }
    @Transactional
    public void deleteById(Long id) {
        empresaRepository.deleteById(id);
    }
}
