package com.reusoil.app.controller.empresa;

import com.reusoil.app.models.empresa.EmpresaAPI;
import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.services.empresa.EmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequiredArgsConstructor
@RequestMapping("/empresa")
@Controller
public class EmpresaController {

    private final EmpresaService empresaService;

    @PostMapping("/guardar")
    public String crearEmpresa(EmpresaEntity nuevaEmpresa){
        nuevaEmpresa.setId(1L);
        empresaService.save(nuevaEmpresa);
        return null;
    }

}
