package com.reusoil.app.models.recoleccion;

import com.reusoil.app.models.empresa.EmpresaEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity(name = "recoleccion")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RecoleccionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "La fecha de recolección es obligatoria")
    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date fechaRecoleccion;

    @NotNull(message = "El volumen recogido es obligatorio")
    @Min(value = 0, message = "El volumen recogido debe ser mayor o igual a 0")
    @Column(nullable = false)
    private Float volumenRecogido;

    @NotNull(message = "La empresa es obligatoria")
    @ManyToOne
    @JoinColumn(name = "id_empresa", referencedColumnName = "id", nullable = false)
    private EmpresaEntity empresa;

    @Column(nullable = false)
    private boolean estado;
}
