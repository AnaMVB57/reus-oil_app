package com.reusoil.app.models.notificacion;

public class NotificacionAPI {
}
