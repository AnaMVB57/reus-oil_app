package com.reusoil.app.models.empresa;

import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EmpresaAPI {

    @Getter
    @Setter
    private String nombre;

    private String direccion;

    private String telefono;

    private String email;

    private Date fechaRegistro;

    private CiudadEntity ciudad;

    private TipoEmpresaEntity tipoEmpresa;

    private boolean estado;
}
