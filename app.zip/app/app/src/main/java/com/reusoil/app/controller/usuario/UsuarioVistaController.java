package com.reusoil.app.controller.usuario;

import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.services.usuario.UsuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

@RequiredArgsConstructor
@Controller
@RequestMapping("/usuario")
public class UsuarioVistaController {

    private final UsuarioService usuarioService;

    @GetMapping("/formulario-usuario")
    public String mostrarFormularioUsuario(Model model) {
        UsuarioEntity usuario = new UsuarioEntity();
        usuario.setEstado(true); // Inicializa el estado como activo
        model.addAttribute("modoEdicion", false);
        model.addAttribute("usuario", usuario);
        return "vistas/usuario/form_usuario"; // Redirige al formulario
    }

    @GetMapping("/listado-usuarios")
    public String mostrarListadoUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioService.obtenerUsuariosTodos());
        model.addAttribute("mensaje", "Listado de usuarios");
        return "vistas/usuario/listado_usuario"; // Asegúrate de tener esta vista
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable("id") Long id, Model model) {
        Optional<UsuarioEntity> usuario = usuarioService.obtenerUsuarioPorId(id);
        if (usuario.isPresent()) {
            model.addAttribute("usuario", usuario.get());
            model.addAttribute("modoEdicion", true); // Indica modo de edición
            return "vistas/usuario/form_usuario"; // Reutiliza el mismo formulario
        }
        return "redirect:/usuario/listado-usuarios"; // Redirige si no se encuentra el usuario
    }
}
