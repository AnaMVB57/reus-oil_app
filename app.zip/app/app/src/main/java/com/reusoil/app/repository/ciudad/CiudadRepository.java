package com.reusoil.app.repository.ciudad;

import com.reusoil.app.models.ciudad.CiudadEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CiudadRepository extends JpaRepository<CiudadEntity, Long> {


}
