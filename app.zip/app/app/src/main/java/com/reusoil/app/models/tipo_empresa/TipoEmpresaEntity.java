package com.reusoil.app.models.tipo_empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity(name = "tipo_empresa")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TipoEmpresaEntity {

    @Getter
    @Setter
    @Id
    private Long id;

    @Column(nullable = false)
    private String tipoEmpresa;

    @Column(nullable = false)
    private boolean estado;

    @OneToMany(mappedBy = "tipoEmpresa")
    private List<EmpresaEntity> empresas;









}
