package com.reusoil.app.repository.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import org.apache.el.stream.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpresaRepository extends JpaRepository<EmpresaEntity, Long> {

    Optional<EmpresaEntity> findById(Long id);

    }
