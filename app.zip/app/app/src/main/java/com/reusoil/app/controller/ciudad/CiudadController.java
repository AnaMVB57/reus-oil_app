package com.reusoil.app.controller.ciudad;

import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.services.ciudad.CiudadService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@Controller
@RequestMapping("/ciudad")
public class CiudadController {

    private final CiudadService ciudadService;

    @GetMapping("/nuevo")
    public String mostrarFormulario(Model model) {
        model.addAttribute("titulo", "Nueva ciudad");
        model.addAttribute("ciudad", new CiudadEntity());
        return "vistas/ciudad/form_ciudad";
    }

    @PostMapping("/guardar")
    public String guardarCiudad(@Valid @ModelAttribute("ciudad") CiudadEntity ciudad,
                                BindingResult bindingResult,
                                Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("titulo", "Nueva ciudad");
            return "vistas/ciudad/form_ciudad";
        }

        ciudadService.guardarCiudad(ciudad);
        return "redirect:/ciudad/mostrar-ciudades";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCiudad(@PathVariable Long id) {
        ciudadService.borradoLogico(id);
        return "redirect:/ciudad/mostrar-ciudades";
    }
}
