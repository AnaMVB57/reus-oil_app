package com.reusoil.app.repository.persona;

import com.reusoil.app.models.persona.PersonaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PersonaRepository extends JpaRepository<PersonaEntity, Long> {

    Optional<PersonaEntity> findByNombre(String nombre);
    Optional<PersonaEntity> findByEstado(boolean estado);
}
