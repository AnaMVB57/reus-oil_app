package com.reusoil.app.repository.tipo_empresa;

public interface Tipo_EmpresaDAOIface {
}
