package com.reusoil.app.services.ciudad;

import com.reusoil.app.models.ciudad.CiudadEntity;

import java.util.List;

public interface CiudadService {

    List<CiudadEntity> obtenerCiudades();

    void guardarCiudad(CiudadEntity ciudad);
}
