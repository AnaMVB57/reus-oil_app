package com.reusoil.app.models.notificacion;

public class NotificacionEntity {
}
