package com.reusoil.app.repository.usuario;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reusoil.app.models.usuario.UsuarioEntity;

public interface UsuarioDAOIface extends JpaRepository<UsuarioEntity, Long>{
    
}