package com.reusoil.app.models.persona;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.models.perfil.PerfilEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "persona")
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonaEntity {

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty
    @NotBlank
    @Column(length = 60, nullable = false, unique = true)
    private String nombre;

    @NotEmpty
    @NotBlank
    private String correo;

    @NotEmpty
    @NotBlank
    private String telefono;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "empresa_id")
    private EmpresaEntity empresa;

    private boolean estado;
}
