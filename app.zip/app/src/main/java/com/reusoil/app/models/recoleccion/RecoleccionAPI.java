package com.reusoil.app.models.recoleccion;

public class RecoleccionAPI {

}
