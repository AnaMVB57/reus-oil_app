package com.reusoil.app.services.tipo_empresa;

import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.repository.tipo_empresa.TipoEmpresaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class TipoEmpresaServiceImpl implements TipoEmpresaService {

    final private TipoEmpresaRepository tipoEmpresaRepository;

    @Override
    public List<TipoEmpresaEntity> obtenerTiposEmpresa() {
        return tipoEmpresaRepository.findAll();
    }

    @Override
    public void guardar(TipoEmpresaEntity tipoEmpresa) {
        tipoEmpresaRepository.save(tipoEmpresa);
    }

    @Override
    public TipoEmpresaEntity obtenerTipoEmpresaPorId(Long id) {
        return tipoEmpresaRepository.findById(id).orElse(null);
    }

    @Override
    public void eliminarPorId(Long id) {
        tipoEmpresaRepository.deleteById(id);
    }
}
