package com.reusoil.app.models.perfil;

public class PerfilAPI {
}
