package com.reusoil.app.repository.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpresaDAOIface extends JpaRepository<EmpresaEntity, Long> {
}
