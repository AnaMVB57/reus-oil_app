package com.reusoil.app.models.contenedor;

import com.reusoil.app.models.empresa.EmpresaEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.Date;

@Entity(name = "contenedor")
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContenedorEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(nullable = false)
    @NotBlank(message = "El campo no puede estar vacío.")
    private float capacidad;

    @NotBlank(message = "El campo no puede estar vacío.")
    @Column(nullable = false)
    private String ubicacion;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechaInst;

    @ManyToOne
    @JoinColumn(name = "idEmpresa", referencedColumnName = "id", nullable = false)
    private EmpresaEntity empresa;

    @Column(nullable = false)
    private boolean estado;

}
