package com.reusoil.app.controller.login;

import com.reusoil.app.models.usuario.UsuarioAPI;
import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final UsuarioServiceImpl usuarioService;

    @PostMapping("/login")
    public String iniciarSesion(@Valid @ModelAttribute("usuario") UsuarioAPI usuarioAPI,
                                BindingResult bindingResult,
                                Model model) {
        if (bindingResult.hasErrors()) {
            return "vistas/inicio/login";
        }

        Optional<UsuarioEntity> usuarioActual = usuarioService.obtenerUsuarioPorUsuario(usuarioAPI.getUsuario());

        if (usuarioActual.isEmpty()) {
            model.addAttribute("error", "Usuario no existe");
            return "vistas/inicio/login";
        }

        if (!usuarioAPI.getClave().equals(usuarioActual.get().getClave())) {
            model.addAttribute("error", "Usuario o contraseña incorrectos.");
            return "vistas/inicio/login";
        }

        return "vistas/homepage";
    }

    @PostMapping("/registrar")
    public String registrar(@Valid @ModelAttribute("usuario") UsuarioAPI usuarioAPI,
                            BindingResult bindingResult,
                            Model model) {
        if (bindingResult.hasErrors()) {
            return "vistas/inicio/login";
        }

        // Verificar si el usuario ya existe
        if (usuarioService.obtenerUsuarioPorUsuario(usuarioAPI.getUsuario()).isPresent()) {
            model.addAttribute("error", "Este usuario está en uso");
            return "vistas/inicio/login";
        }

        // Lógica para registrar al usuario
        usuarioService.guardarUsuario(
                UsuarioEntity.builder()
                        .usuario(usuarioAPI.getUsuario())
                        .clave(usuarioAPI.getClave())
                        .build()
        );

        return "redirect:/mostrar-login";
    }
}
