//package com.reusoil.app.services.usuario2;
//
//import com.reusoil.app.models.usuario.UsuarioEntity;
//
//import java.util.List;
//import java.util.Optional;
//
//public interface UsuarioServiceIface {
//
//    List<UsuarioEntity> obtenerUsuariosTodos(UsuarioEntity usuarioEntity);
//    Optional<UsuarioEntity> obtenerUsuarioPorId(Long id);
//    void eliminarUsuarioPorId(Long id);
//    void guardarUsuario(UsuarioEntity usuarioEntity);
//    UsuarioEntity obtenerUsuarioPorUsuario(String usuario);
//}