package com.reusoil.app.services.tipo_sensor;

public class Tipo_SensorService {
}
