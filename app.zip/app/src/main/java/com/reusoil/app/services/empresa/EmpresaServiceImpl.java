package com.reusoil.app.services.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.repository.empresa.EmpresaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class EmpresaServiceImpl implements EmpresaService{

    final private EmpresaRepository empresaRepository;
    @Override
    @Transactional(readOnly = true)
    public List<EmpresaEntity> obtenerEmpresas() {
        return empresaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EmpresaEntity> obtenerEmpresaPorId(Long id) {
        return empresaRepository.findById(id);
    }

    @Override
    @Transactional
    public void guardar(EmpresaEntity empresa) {
        empresaRepository.save(empresa);
    }

    @Override
    @Transactional
    public void eliminarEmpresaPorId(Long id) {
        empresaRepository.deleteById(id);
    }

    public EmpresaEntity actualizarNit(Long id, Long nuevoNit) throws Exception {
        // Buscar la empresa por su NIT actual (ID)
        Optional<EmpresaEntity> empresaExistente = empresaRepository.findById(id);

        if (empresaExistente.isPresent()) {
            // Verificar si el nuevo NIT ya está registrado como ID en otra empresa
            Optional<EmpresaEntity> empresaConNuevoNit = empresaRepository.findById(nuevoNit);

            if (empresaConNuevoNit.isPresent()) {
                throw new Exception("El NIT ingresado ya está en uso.");
            } else {
                // Actualizar el NIT (ID) si no existe en la base de datos
                EmpresaEntity empresa = empresaExistente.get();
                empresa.setId(nuevoNit);
                return empresaRepository.save(empresa);
            }
        } else {
            throw new Exception("La empresa con el ID proporcionado no existe.");
        }
    }
}
