package com.reusoil.app.controller.login;

import com.reusoil.app.models.usuario.UsuarioAPI;
import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class LoginVistaController {

    private final UsuarioServiceImpl usuarioService;

    @GetMapping("/mostrar-login")
    public String mostrarFormularioLogin(Model model) {
        model.addAttribute("usuario", new UsuarioAPI());
        return "vistas/inicio/login";
    }

//    @GetMapping("/mostrar-registro")
//    public String mostrarFormularioRegistro(Model model) {
//        model.addAttribute("usuario", new UsuarioAPI());
//        return "vistas/inicio/registro";
//    }

    @GetMapping("/home")
    public String homePage() {
        return "vistas/homepage";
    }


//    @PostMapping("/login")
//    public String iniciarSesion(@Valid @ModelAttribute("usuario") UsuarioAPI usuarioAPI,
//                                BindingResult bindingResult,
//                                Model model) {
//        if (bindingResult.hasErrors()) {
//            return "vistas/login"; // Volver al formulario si hay errores de validación
//        }
//
//        var usuarioActual = usuarioService.obtenerUsuarioPorUsuario(usuarioAPI.getUsuario());
//
//        if (usuarioActual == null) {
//            model.addAttribute("error", "Usuario no existe");
//            return "vistas/login";
//        }
//
//        if (!usuarioAPI.getClave().equals(usuarioActual.getClave())) {
//            model.addAttribute("error", "Usuario o contraseña incorrectos.");
//            return "vistas/login";
//        }
//
//        return "vistas/homepage";
//    }
//
//    @PostMapping("/registrar")
//    public String registrar(@Valid @ModelAttribute("usuario") UsuarioAPI usuarioAPI,
//                            BindingResult bindingResult,
//                            Model model) {
//        if (bindingResult.hasErrors()) {
//            return "vistas/login"; // Volver al formulario si hay errores de validación
//        }
//
//        // Lógica para registrar al usuario
//        usuarioService.guardarUsuario(
//                UsuarioEntity.builder()
//                        .usuario(usuarioAPI.getUsuario())
//                        .clave(usuarioAPI.getClave())
//                        .build()
//        );
//
//        return "redirect:/mostrar-login";
//    }
//


//    @PostMapping("/login")
//    public String iniciarSesion(@RequestParam("usuarioLogin") String usuario,
//                                @RequestParam("claveLogin") String clave,
//                                Model model) {
//        var usuarioActual = usuarioService.obtenerUsuarioPorUsuario(usuario);
//
//        if (usuario.isEmpty() || clave.isEmpty()) {
//            model.addAttribute("error", "Todos los campos son obligatorios.");
//            return "vistas/login";
//        }
//
//        if(usuarioActual == null) {
//            model.addAttribute("error", "Usuario no existe");
//             return "vistas/login";
//        }
//
//        if (!usuario.equals(usuarioActual.getUsuario()) || !clave.equals(usuarioActual.getClave())) {
//            model.addAttribute("error", "Usuario o contraseña incorrectos.");
//            return "vistas/login";
//        }
//        return "vistas/homepage";
//    }

//    @PostMapping("/login")
//    public String iniciarSesion(@Valid @ModelAttribute("usuarioDTO") UsuarioAPI usuarioAPI,
//                                BindingResult bindingResult,
//                                Model model) {
//        if (bindingResult.hasErrors()) {
//            return "vistas/login"; // Volver al formulario si hay errores de validación
//        }
//
//        var usuarioActual = usuarioService.obtenerUsuarioPorUsuario(usuarioAPI.getUsuario());
//
//        if (usuarioActual == null) {
//            model.addAttribute("error", "Usuario no existente");
//            return "vistas/login";
//        }
//
//        if (!usuarioAPI.getClave().equals(usuarioActual.getClave())) {
//            model.addAttribute("error", "Usuario o contraseña incorrectos.");
//            return "vistas/login";
//        }
//
//        return "vistas/homepage";
//    }

//    @PostMapping("/registrar")
//    public String registrar(@RequestParam("usuarioLogin") String usuario,
//                           @RequestParam("claveLogin") String clave,
//                           Model model) {
//        return "vistas/login";
//    }

//    @PostMapping("/registrar")
//    public String registrar(@Valid @ModelAttribute("usuarioDTO") UsuarioAPI usuarioAPI,
//                            BindingResult bindingResult,
//                            Model model) {
//        if (bindingResult.hasErrors()) {
//            return "vistas/login";
//        }
//
//        usuarioService.guardarUsuario(
//                UsuarioEntity.builder()
//                        .usuario(usuarioAPI.getUsuario())
//                        .clave(usuarioAPI.getClave())
//                        .build()
//        );
//
//        return "redirect:/mostrar-login";
//    }



}
