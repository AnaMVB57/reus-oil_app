package com.reusoil.app.controller.ciudad;


import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.services.ciudad.CiudadService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

@RequiredArgsConstructor
@Controller
@RequestMapping("/ciudad")
public class CiudadVistaController {

    private final CiudadService ciudadService;

    @GetMapping("/nueva-ciudad")
    public String MostrarFormularioCiudad(Model model) {
        model.addAttribute("ciudad", new CiudadEntity());
        model.addAttribute("titulo", "Nueva ciudad");
        return "vistas/ciudad/form_ciudad";

    }

    @GetMapping("/mostrar-ciudades")
    public String mostrarCiudades(Model model) {
        model.addAttribute("ciudad", new CiudadEntity()); // O el objeto necesario para tu vista
        model.addAttribute("ciudades", ciudadService.obtenerCiudades()); // Lista de ciudades, si es necesario
        return "vistas/ciudad/listado_ciudad";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
        Optional<CiudadEntity> ciudadOptional = ciudadService.obtenerCiudadPorId(id);
        if (ciudadOptional.isPresent()) {
            model.addAttribute("tipoEmpresa", ciudadOptional.get());
            return "vistas/ciudad/form_ciudad"; // Asegúrate de que el nombre del archivo coincida
        }
        return "redirect:/ciudad/mostrar-ciudades"; // Redirigir si no se encuentra el tipo de empresa
    }
}
