package com.reusoil.app.controller.ciudad;


import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.services.ciudad.CiudadService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequiredArgsConstructor
@Controller
@RequestMapping("/ciudad")
public class CiudadVistaController {

    private final CiudadService ciudadService;

    @GetMapping("/nueva-ciudad")
    public String MostrarFormularioCiudad(Model model) {
        model.addAttribute("ciudad", new CiudadEntity());
        model.addAttribute("titulo", "Nueva ciudad");
        return "vistas/ciudad/form_ciudad";

    }
}
