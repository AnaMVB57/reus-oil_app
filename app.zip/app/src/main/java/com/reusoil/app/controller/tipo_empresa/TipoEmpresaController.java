package com.reusoil.app.controller.tipo_empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.services.tipo_empresa.TipoEmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RequiredArgsConstructor
@Controller
@RequestMapping("/tipo-empresa")
public class TipoEmpresaController {

    private final TipoEmpresaService tipoEmpresaService;

    // Guardar (crear o actualizar) un tipo de empresa
    @PostMapping("/guardar")
    public String crearOActualizarTipoEmpresa(@ModelAttribute("tipoEmpresa") TipoEmpresaEntity tipoEmpresa, Model model) {
        try {
            // Verificar si el tipo de empresa ya existe por su ID
            if (tipoEmpresa.getId() != null && tipoEmpresaService.obtenerTipoEmpresaPorId(tipoEmpresa.getId()).isPresent()) {
                // Si el ID existe, se actualiza el registro
                tipoEmpresaService.guardar(tipoEmpresa);
            } else {
                // Si no tiene ID o no existe en la BD, se crea uno nuevo
                tipoEmpresa.setId(null); // Asegúrate de que el ID esté en null si es un nuevo registro
                tipoEmpresaService.guardar(tipoEmpresa);
            }
            return "redirect:/tipo-empresa/listado"; // Redirigir a la lista de tipos de empresa después de guardar
        } catch (Exception e) {
            // Manejo de errores
            model.addAttribute("error", "Ocurrió un error al guardar el tipo de empresa.");
            model.addAttribute("tipoEmpresa", tipoEmpresa); // Reenviar los datos del tipo de empresa al formulario
            return "vistas/tipo-empresa/form_tipo-empresa"; // Redirigir al formulario en caso de error
        }
    }


//    // Mostrar el formulario para editar un tipo de empresa
//    @GetMapping("/editar/{id}")
//    public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
//        Optional<TipoEmpresaEntity> tipoEmpresa = Optional.ofNullable(tipoEmpresaService.obtenerTipoEmpresaPorId(id));
//        if (tipoEmpresa.isPresent()) {
//            model.addAttribute("tipoEmpresa", tipoEmpresa.get());
//            return "vistas/tipo-empresa/form_tipo_empresa"; // Retornar al formulario de edición
//        }
//        return "redirect:/tipo-empresa/listado"; // Redirigir si no se encuentra el tipo de empresa
//    }

    @PostMapping("/editar")
    public String guardarEdicion(@ModelAttribute("tipoEmpresa") TipoEmpresaEntity tipoEmpresa) {
        tipoEmpresaService.guardar(tipoEmpresa);
        return "redirect:/tipo-empresa/listado";
    }

    // Eliminar un tipo de empresa
    @GetMapping("/eliminar/{id}")
    public String eliminarTipoEmpresa(@PathVariable Long id) {
        tipoEmpresaService.eliminarPorId(id);
        return "redirect:/tipo-empresa/listado"; // Redirigir después de eliminar
    }
}
