package com.reusoil.app.controller.tipo_empresa;

import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.services.tipo_empresa.TipoEmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@Controller
@RequestMapping("/tipo-empresa")
public class TipoEmpresaController {

    private final TipoEmpresaService tipoEmpresaService;

    // Crear un nuevo tipo de empresa
    @PostMapping("/guardar")
    public String crearTipoEmpresa(@ModelAttribute("tipoEmpresa") TipoEmpresaEntity tipoEmpresa) {
        tipoEmpresaService.guardar(tipoEmpresa);
        return "redirect:/tipo-empresa/listado";
    }

    // Eliminar un tipo de empresa
//    @DeleteMapping("/eliminar/{id}")
//    public void eliminarTipoEmpresa(@PathVariable Long id) {
//        tipoEmpresaService.eliminarPorId(id);
//    }

//    @GetMapping("/todos")
//    public List<TipoEmpresaEntity> obtenerTodosLosTiposEmpresa() {
//        return tipoEmpresaService.obtenerTiposEmpresa();
//    }
//
//    @GetMapping("/{id}")
//    public TipoEmpresaEntity obtenerTipoEmpresaPorId(@PathVariable Long id) {
//        return tipoEmpresaService.obtenerTipoEmpresaPorId(id);
//    }

//
//
//    // Actualizar un tipo de empresa
//    @PutMapping("/actualizar/{id}")
//    public void actualizarTipoEmpresa(@PathVariable Long id, @RequestBody TipoEmpresaEntity tipoEmpresa) {
//        tipoEmpresa.setId(id);
//        tipoEmpresaService.guardar(tipoEmpresa);
//    }

}
