package com.reusoil.app.controller.tipo_empresa;

import com.reusoil.app.models.tipoempresa.TipoEmpresaEntity;
import com.reusoil.app.services.tipo_empresa.TipoEmpresaService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.util.List;

@Controller
@RequestMapping("/tipo-empresa")
public class TipoEmpresaController {

    private final TipoEmpresaService tipoEmpresaService;

    public TipoEmpresaController(TipoEmpresaService tipoEmpresaService) {
        this.tipoEmpresaService = tipoEmpresaService;
    }

    @PostMapping("/registrar")
    public String registrarTipoEmpresa(@ModelAttribute TipoEmpresaEntity tipoEmpresa) {
        tipoEmpresaService.save(tipoEmpresa);
        return "redirect:/tipo-empresa/";
    }

    @GetMapping("/{id}")
    public TipoEmpresaEntity obtenerTipoEmpresa(@PathVariable Long id) {
        return tipoEmpresaService.findById(id).orElse(null);
    }

    @PutMapping("/actualizar")
    public TipoEmpresaEntity actualizarTipoEmpresa(@RequestBody TipoEmpresaEntity tipoEmpresa) {
        return tipoEmpresaService.save(tipoEmpresa);
    }

    @DeleteMapping("/eliminar/{id}")
    public String eliminarTipoEmpresa(@PathVariable Long id) {
        tipoEmpresaService.deleteById(id);
        return "redirect:/tipo-empresa/";
    }

    @GetMapping("/todos")
    public String obtenerTodosLosTiposDeEmpresa(Model model) {
        List<TipoEmpresaEntity> tipos = tipoEmpresaService.findAll();
        model.addAttribute("tipos", tipos);
        return "";
    }
}
