package com.reusoil.app.repository.ciudad;

import com.reusoil.app.models.ciudad.CiudadEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
public interface CiudadRepository extends JpaRepository<CiudadEntity, Long> {


}
