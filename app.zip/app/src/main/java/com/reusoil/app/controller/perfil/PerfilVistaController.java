package com.reusoil.app.controller.perfil;

import com.reusoil.app.models.perfil.PerfilEntity;
import com.reusoil.app.services.perfil.PerfilService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RequiredArgsConstructor
@Controller
@RequestMapping("/perfil")
public class PerfilVistaController {

    private final PerfilService perfilService;

    // Mostrar listado de todos los perfiles
    @GetMapping("/listado")
    public String mostrarListado(Model model) {
        model.addAttribute("perfiles", perfilService.obtenerPerfiles());
        return "vistas/perfil/listado_perfil"; // Asegúrate de que esta ruta sea correcta
    }

    // Mostrar formulario para editar un perfil existente
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable("id") Long id, Model model) {
        Optional<PerfilEntity> perfil = perfilService.obtenerPerfilPorId(id);
        if (perfil.isPresent()) {
            model.addAttribute("perfilEntity", perfil.get()); // Cambia 'perfil' a 'perfilEntity' para que coincida con el nombre usado en el formulario
            return "vistas/perfil/form_perfil"; // Asegúrate de que esta ruta sea correcta
        }
        return "redirect:/perfil/listado"; // Redirige si no se encuentra el perfil
    }

    // Eliminar un perfil por ID
    @GetMapping("/eliminar/{id}")
    public String eliminarPerfil(@PathVariable("id") Long id) {
        perfilService.eliminarPerfilPorId(id); // Llama al método del servicio para eliminar el perfil
        return "redirect:/perfil/listado"; // Redirige al listado después de eliminar
    }
}
