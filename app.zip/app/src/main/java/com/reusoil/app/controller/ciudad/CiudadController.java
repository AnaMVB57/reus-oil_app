package com.reusoil.app.controller.ciudad;



import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.services.ciudad.CiudadService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@RequiredArgsConstructor
@Controller
@RequestMapping("/ciudad")
public class CiudadController {

    private final CiudadService ciudadService;

    @PostMapping("/guardar")
    public String guardarCiudad(@ModelAttribute("ciudad") CiudadEntity ciudad) {
        ciudadService.guardarCiudad(ciudad);
        return "redirect:/ciudad/mostrar-ciudades";
    }


    @GetMapping("/mostrar-ciudades")
    public String mostrarCiudades(Model model) {
        model.addAttribute("ciudad", new CiudadEntity()); // O el objeto necesario para tu vista
        model.addAttribute("ciudades", ciudadService.obtenerCiudades()); // Lista de ciudades, si es necesario
        return "vistas/ciudad/listado_ciudad";
    }




}
