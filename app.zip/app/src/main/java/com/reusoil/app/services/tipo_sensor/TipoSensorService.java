package com.reusoil.app.services.tipo_sensor;

import com.reusoil.app.models.tipo_sensor.TipoSensorEntity;

import java.util.List;

public interface TipoSensorService {

    public List<TipoSensorEntity> obtenerTiposSensor();
    }



