package com.reusoil.app.services.tipo_sensor;

import com.reusoil.app.models.tipo_sensor.TipoSensorEntity;
import com.reusoil.app.repositories.TipoSensorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TipoSensorService {

    final private TipoSensorRepository tipoSensorRepository;

    public TipoSensorService(TipoSensorRepository tipoSensorRepository){
        this.tipoSensorRepository = tipoSensorRepository;
    }

    @Transactional(readOnly = true)
    public List<TipoSensorEntity> findAll() {
        return tipoSensorRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<TipoSensorEntity> findById(Long id) {
        return tipoSensorRepository.findById(id);
    }

    @Transactional
    public TipoSensorEntity save(TipoSensorEntity tipoSensor) {
        return tipoSensorRepository.save(tipoSensor);
    }

    @Transactional
    public void deleteById(Long id) {
        tipoSensorRepository.deleteById(id);
    }
}
