package com.reusoil.app.models;

import lombok.Data;

@Data
public class UsuarioApi {

    private String usuario;
    private String clave;
}
