package com.reusoil.app.services.tipo_empresa;

import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.repository.tipo_empresa.TipoEmpresaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TipoEmpresaService {

    final private TipoEmpresaRepository tipoEmpresaRepository;

    public TipoEmpresaService(TipoEmpresaRepository tipoEmpresaRepository){
        this.tipoEmpresaRepository = tipoEmpresaRepository;
    }

    @Transactional(readOnly = true)
    public List<TipoEmpresaEntity> findAll() {
        return tipoEmpresaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<TipoEmpresaEntity> findById(Long id) {
        return tipoEmpresaRepository.findById(id);
    }

    @Transactional
    public TipoEmpresaEntity save(TipoEmpresaEntity tipoEmpresa) {
        return tipoEmpresaRepository.save(tipoEmpresa);
    }

    @Transactional
    public void deleteById(Long id) {
        tipoEmpresaRepository.deleteById(id);
    }
}
