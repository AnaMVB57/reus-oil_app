package com.reusoil.app.models.tipo_sensor;

import jakarta.persistence.Id;
import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TipoSensorEntity {

    @Id
    private Long id;
}
