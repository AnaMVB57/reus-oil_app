package com.reusoil.app.controller.usuario;

import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioVistaController {

    private final UsuarioServiceImpl usuarioService;



//    @GetMapping("/listado-usuarios")
//    public String mostrarListadoDeUsuarios() {
//        List<UsuarioEntity> usuarios = usuarioService.obtenerUsuariosTodos();
//        return "vistas/usuario/listado_usuario";
//    }

}
