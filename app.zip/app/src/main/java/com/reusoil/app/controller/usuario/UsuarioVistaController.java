package com.reusoil.app.controller.usuario;

import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioVistaController {

    private final UsuarioServiceImpl usuarioService;

    @GetMapping("/todos")
    public List<UsuarioEntity> obtenerTodosLosUsuarios() {
        return usuarioService.obtenerUsuariosTodos();
    }

}
