package com.reusoil.app.controller.usuario;

import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioVistaController {

    private final UsuarioServiceImpl usuarioService;

    //Recuerda implementar un método en UsuarioService
    // para obtener usuarios por estado (el estado debe ser true para que se muestren)

//    @GetMapping("/listado-usuarios")
//    public String mostrarListadoDeUsuarios() {
//        List<UsuarioEntity> usuarios = usuarioService.obtenerUsuariosTodos();
//        return "vistas/usuario/listado_usuario";
//    }


}
