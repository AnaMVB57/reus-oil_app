package com.reusoil.app.models.arduino;

public class ArduinoAPI {
}
