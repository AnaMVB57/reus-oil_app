package com.reusoil.app.services.perfil;

import com.reusoil.app.models.perfil.PerfilEntity;
import com.reusoil.app.repository.perfil.PerfilRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class PerfilServiceImpl implements PerfilService {

    private final PerfilRepository perfilRepository;

    @Transactional(readOnly = true)
    public List<PerfilEntity> obtenerPerfiles() {
        return perfilRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<PerfilEntity> obtenerPerfilPorId(Long id) {
        return perfilRepository.findById(id);
    }

    @Transactional
    public void guardar(PerfilEntity perfil) {
        perfilRepository.save(perfil);
    }

    @Transactional
    public void eliminarPerfilPorId(Long id) {
        perfilRepository.deleteById(id);
    }
}
