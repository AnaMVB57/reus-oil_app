package com.reusoil.app.controller.tipo_empresa;

import com.reusoil.app.models.tipo_empresa.TipoEmpresaAPI;
import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.services.tipo_empresa.TipoEmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequiredArgsConstructor
@Controller
@RequestMapping("/tipo-empresa")
public class TipoEmpresaVistaController {

    private final TipoEmpresaService tipoEmpresaService;

    // ("/listado-tipo-empresa")
    @GetMapping("/listado")
    public String mostrarListadoTipoEmpresa(Model model) {
        model.addAttribute("tiposEmpresas", tipoEmpresaService.obtenerTiposEmpresa());
        return "vistas/tipo-empresa/listado";
    }

    @GetMapping("/nuevo-tipo-empresa")
    public String mostrarFormularioTipoEmpresa(Model model) {
        model.addAttribute("tipoEmpresa", new TipoEmpresaEntity());
        return "vistas/tipo-empresa/form_tipo-empresa";
    }

    @GetMapping("/editar/{id}")
    public String tipoEmpresaModificar(@PathVariable(value = "id") Long id, Model model) {
        TipoEmpresaEntity tipoEmpresa = null;
        if (id > 0) {
            tipoEmpresa = tipoEmpresaService.obtenerTipoEmpresaPorId(id);
            if (tipoEmpresa == null) {
                return "vistas/tipo-empresa/listado";
            }
        }
        model.addAttribute("titulo", "Modificar tipo de empresa");
        model.addAttribute("tipoEmpresa", tipoEmpresa);
        return "vistas/tipo-empresa/form_tipo-empresa";
    }



    @GetMapping("/consultar/{id}")
    public String consultarTipoEmpresa(@RequestParam Long id, Model model) {
        tipoEmpresaService.obtenerTipoEmpresaPorId(id);
        model.addAttribute("titulo", "Detalles de ");
        return "vistas/tipo-empresa/consulta_tipo-empresa";
    }


}
