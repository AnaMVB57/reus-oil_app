package com.reusoil.app.services.tipo_sensor;

import com.reusoil.app.models.tipo_sensor.TipoSensorEntity;
import com.reusoil.app.repository.tipo_sensor.TipoSensorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class TipoSensorServiceImpl implements TipoSensorService{

    private final TipoSensorRepository tipoSensorRepository;
    @Override
    public List<TipoSensorEntity> obtenerTiposSensor() {
        return tipoSensorRepository.findAll();
    }
}
