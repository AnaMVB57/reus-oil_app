package com.reusoil.app.models.perfil;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "perfil")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PerfilEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "descripcion_perfil", nullable = false)
    private String descPerfil;

    @Column(name = "estado")
    private boolean estado;

    public boolean getEstado(){
        return estado;
    }
}
