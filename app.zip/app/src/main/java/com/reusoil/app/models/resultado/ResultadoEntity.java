package com.reusoil.app.models.resultado;

public class ResultadoEntity {
}
