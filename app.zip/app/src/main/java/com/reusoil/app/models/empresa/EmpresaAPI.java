package com.reusoil.app.models.empresa;

public class EmpresaAPI {
}
