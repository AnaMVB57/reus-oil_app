package com.reusoil.app.controller.usuario;

import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.models.usuario.UsuarioAPI;
import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioServiceImpl usuarioService;

    @PostMapping("/registrar")
    public String registrarUsuario(@Valid @ModelAttribute UsuarioAPI usuario,
                                   BindingResult bindingResult,
                                   Model model) {
        // Verificar si el usuario ya existe
        if (usuarioService.obtenerUsuarioPorUsuario(usuario.getUsuario()) != null) {
            bindingResult.rejectValue("usuario", "error.usuario", "Este usuario está en uso");
        }

        // Si hay errores de validación, volver al formulario
        if (bindingResult.hasErrors()) {
            model.addAttribute("usuario", usuario); // Para que se mantengan los datos en el formulario
            return "vistas/login"; // Regresar al formulario de registro
        }

        // Guardar el nuevo usuario
        usuarioService.registrarUsuario(
                UsuarioEntity.builder()
                        .usuario(usuario.getUsuario())
                        .clave(usuario.getClave())
                        .build()
        );

        return "redirect:/mostrar-login";
    }

//    @PostMapping("/registrar")
//    public String registrarUsuario(@ModelAttribute UsuarioAPI usuario) {
//        usuarioService.registrarUsuario(
//                UsuarioEntity.builder()
//                        .usuario(usuario.getUsuario())
//                        .clave(usuario.getClave())
//                        .build()
//        );
//        return "redirect:/mostrar-login";
//    }

    @GetMapping("/{id}")
    public UsuarioEntity obtenerUsuario(@PathVariable Long id) {
        return usuarioService.obtenerUsuarioPorId(id).orElse(null);
    }

//    @PutMapping("/actualizar")
//    public UsuarioEntity actualizarUsuario(@RequestBody UsuarioEntity usuarioEntity) {
//        return usuarioService.actualizarUsuario(usuarioEntity);
//    }


}
