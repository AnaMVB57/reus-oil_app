package com.reusoil.app.controller.usuario;

import com.reusoil.app.models.usuario.UsuarioAPI;
import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import com.reusoil.app.services.utils.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioServiceImpl usuarioService;
    private final EmailService emailService;

    @PostMapping("/registrar")
    public String registrarUsuario(@ModelAttribute UsuarioAPI usuario) {
        usuarioService.guardarUsuario(
                UsuarioEntity.builder()
                        .usuario(usuario.getUsuario())
                        .clave(usuario.getClave())
                        .build()
        );
        return "redirect:/mostrar-login";
    }

    @GetMapping("/usuarioRecuperarContrasena")
    public String recuperarUsuario(Model model) {
        UsuarioEntity usuario = new UsuarioEntity();
        model.addAttribute("usuario", usuario);
        model.addAttribute("mensaje", "");
        return "plantillas/recuperar-clave";
    }

    @PostMapping("/recuperarUsuario")
    public String recuperarContrasena(@RequestParam("email") String email, Model model, SessionStatus status) {
        //Usuario usuarioExistente = usuarioService.consultar(email);
        System.out.println("email: "+email);

        List<UsuarioEntity> usuarios= usuarioService.obtenerUsuariosTodos();
        for (UsuarioEntity usuario : usuarios) {
            if (email.equals( usuario.getUsuario())) {
                String contrasena = usuario.getClave(); // Obtener la contraseña

                String mensaje = "Su contraseña es: " + contrasena;
                emailService.enviarCorreo(email, "Recuperación de contraseña", mensaje);

                status.setComplete();
                model.addAttribute("mensaje", "Se ha enviado su contraseña al correo electrónico.");
                System.out.println("Cumplio "+usuario.getUsuario());

                return "plantillas/recuperar-clave";
            }
            System.out.println("No cumplio "+usuario.getUsuario());
        }
        model.addAttribute("error", "No se encontró un usuario con ese email.");
        return "plantillas/recuperar-clave";

    }

    @GetMapping("/{id}")
    public UsuarioEntity obtenerUsuario(@PathVariable Long id) {
        return usuarioService.obtenerUsuarioPorId(id).orElse(null);
    }


    @GetMapping("/todos")
    public List<UsuarioEntity> obtenerTodosLosUsuarios() {
        return usuarioService.obtenerUsuariosTodos();
    }

//    @PutMapping("/actualizar")
//    public UsuarioEntity actualizarUsuario(@RequestBody UsuarioEntity usuarioEntity) {
//        return usuarioService.guardarUsuario(usuarioEntity);
//    }

    // @DeleteMapping("/eliminar/{id}")
    // public void eliminarUsuario(@PathVariable Long id) {
    //     usuarioService.eliminarUsuario(id);
    // }

}
