package com.reusoil.app.controller.usuario;

import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.services.usuario.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RequestMapping("/usuario")
@Controller
public class UsuarioController {

    private final UsuarioService usuarioService;

    @PostMapping("/guardar")
    public String crearOActualizarUsuario(@Valid @ModelAttribute("usuarioGuardar") UsuarioEntity usuario,
                                          BindingResult bindingResult,
                                          Model model) {
        // Verificar errores de validación
        if (bindingResult.hasErrors()) {
            model.addAttribute("error", "Por favor, corrija los errores en el formulario");
            return "vistas/usuario/form_usuario"; // Volver al formulario con errores de validación
        }

        usuarioService.guardarUsuario(usuario);
        return "redirect:/usuario/listado-usuarios";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarUsuario(@PathVariable Long id) {
        usuarioService.borradoLogico(id);
        return "redirect:/usuario/listado-usuarios";
    }


}
