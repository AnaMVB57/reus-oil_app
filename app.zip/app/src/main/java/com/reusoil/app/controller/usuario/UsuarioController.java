package com.reusoil.app.controller.usuario;

import com.reusoil.app.models.usuario.UsuarioAPI;
import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.services.usuario.UsuarioServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioServiceImpl usuarioService;


    @PostMapping("/registrar")
    public String registrarUsuario(@ModelAttribute UsuarioAPI usuario) {
        usuarioService.guardarUsuario(
                UsuarioEntity.builder()
                        .usuario(usuario.getUsuario())
                        .clave(usuario.getClave())
                        .build()
        );
        return "redirect:/mostrar-login";
    }

    @GetMapping("/{id}")
    public UsuarioEntity obtenerUsuario(@PathVariable Long id) {
        return usuarioService.obtenerUsuarioPorId(id).orElse(null);
    }

//    @PutMapping("/actualizar")
//    public UsuarioEntity actualizarUsuario(@RequestBody UsuarioEntity usuarioEntity) {
//        return usuarioService.guardarUsuario(usuarioEntity);
//    }

    // @DeleteMapping("/eliminar/{id}")
    // public void eliminarUsuario(@PathVariable Long id) {
    //     usuarioService.eliminarUsuario(id);
    // }

    @GetMapping("/todos")
    public List<UsuarioEntity> obtenerTodosLosUsuarios() {
        return usuarioService.obtenerUsuariosTodos();
    }
}
