package com.reusoil.app.models.empresa;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity(name = "empresa")
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor

public class EmpresaEntity {

    @Id
    private Long id;

    @NotBlank
    private String nombre;

    @NotBlank
    private String direccion;

    @NotBlank
    private String telefono;

    @NotBlank
    private String email;

    @NotNull
    @Temporal(TemporalType.DATE)
    @Column(name = "fecha_registro")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private Date fechaRegistro = new Date();

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "idCiudad", referencedColumnName = "id", nullable = false)
    private CiudadEntity ciudad;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "idTipoEmpresa", referencedColumnName = "id", nullable = false)
    private TipoEmpresaEntity tipoEmpresa;

    @Column(nullable = false)
    private boolean estado;

}
