package com.reusoil.app.models.tipo_empresa;

public class TipoEmpresaAPI {
}
