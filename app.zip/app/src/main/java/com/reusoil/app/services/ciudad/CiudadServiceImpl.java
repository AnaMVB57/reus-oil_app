package com.reusoil.app.services.ciudad;

import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.models.tipo_empresa.TipoEmpresaEntity;
import com.reusoil.app.repository.ciudad.CiudadRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CiudadServiceImpl implements CiudadService {
    private final CiudadRepository ciudadRepository;

    @Override
    public List<CiudadEntity> obtenerCiudades() {
        return ciudadRepository.findAll();
    }

    @Override
    public void guardarCiudad(CiudadEntity ciudad) {
//        ciudadRepository.save(ciudad); // Guardar la ciudad en la base de datos

        if (ciudad.getId() != null) {
            Optional<CiudadEntity> ciudadExistente = ciudadRepository.findById(ciudad.getId());
            if (ciudadExistente.isPresent()) {
                // Si el ID ya existe, actualizamos el registro existente
                CiudadEntity ciudadActualizada = ciudadExistente.get();

                // Actualizamos los campos relevantes del registro
//                tipoEmpresaActualizada.setNombre(tipoEmpresa.getNombre());
                ciudadActualizada.setNombre(ciudad.getNombre());
                // Aquí puedes actualizar cualquier otro campo necesario

                ciudadRepository.save(ciudadActualizada);
            } else {
                // Si el ID no existe en la base de datos, creamos un nuevo registro
                ciudad.setId(null); // Asegurar que el ID esté en null para crear un nuevo registro
                ciudadRepository.save(ciudad);
            }
        } else {
            // Si el ID es nulo, creamos un nuevo registro
            ciudadRepository.save(ciudad);
        }
    }

    @Override
    public Optional<CiudadEntity> obtenerCiudadPorId(Long id) {
        return Optional.empty();
    }

    @Override
    public Optional<CiudadEntity> obtenerCiudadPorNombre(String nombre) {
        return Optional.empty();
    }

    @Override
    public void eliminarPorId(Long id) {

    }

    @Override
    public void borradoLogico(Long id) {

    }

    @Override
    public List<CiudadEntity> obtenerCiudadPorEstado(boolean estado) {
        return null;
    }
}
