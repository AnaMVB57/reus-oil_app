package com.reusoil.app.services.ciudad;

import com.reusoil.app.models.ciudad.CiudadEntity;
import com.reusoil.app.repository.ciudad.CiudadRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class CiudadServiceImpl implements CiudadService{
    private final CiudadRepository ciudadRepository;
    @Override
    public List<CiudadEntity> obtenerCiudades() {
        return ciudadRepository.findAll();
    }
}
