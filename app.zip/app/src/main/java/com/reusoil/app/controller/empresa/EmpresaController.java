package com.reusoil.app.controller.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.services.empresa.EmpresaService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.util.List;

@Controller
@RequestMapping("/empresa")
public class EmpresaController {

    private final EmpresaService empresaService;

    public EmpresaController(EmpresaService empresaService) {
        this.empresaService = empresaService;
    }

//    @PostMapping("/registrar")
//    public String registrarEmpresa(@ModelAttribute EmpresaEntity empresa) {
//        empresaService.save(empresa);
//        return "redirect:/empresa/";
//    }
//
//    @GetMapping("/{id}")
//    public EmpresaEntity obtenerEmpresa(@PathVariable Long id) {
//        return empresaService.findById(id).orElse(null);
//    }
//
//    @PutMapping("/actualizar")
//    public EmpresaEntity actualizarEmpresa(@RequestBody EmpresaEntity empresa) {
//        return empresaService.save(empresa);
//    }
//
//    @DeleteMapping("/eliminar/{id}")
//    public String eliminarEmpresa(@PathVariable Long id) {
//        empresaService.deleteById(id);
//        return "redirect:/empresa/";
//    }
//
//    @GetMapping("/todos")
//    public String obtenerTodasLasEmpresas(Model model) {
//        List<EmpresaEntity> empresas = empresaService.findAll();
//        model.addAttribute("empresas", empresas);
//        return "vistas/empresa";
//    }
}
