package com.reusoil.app.controller.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.services.ciudad.CiudadService;
import com.reusoil.app.services.empresa.EmpresaService;
import com.reusoil.app.services.tipo_empresa.TipoEmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RequiredArgsConstructor
@RequestMapping("/empresa")
@Controller
public class EmpresaController {

    private final CiudadService ciudadService;
    private final EmpresaService empresaService;
    private final TipoEmpresaService tipoEmpresaService;

//    @PostMapping("/guardar")
//    public String crearEmpresa(EmpresaEntity nuevaEmpresa){
//        empresaService.guardar(nuevaEmpresa);
//        return "redirect:/empresa/listado-empresas";
//    }

    @PostMapping("/guardar")
    public String crearOActualizarEmpresa(@ModelAttribute("empresa") EmpresaEntity empresa, Model model) {
        try {
            // Verificar si el NIT ya existe
            Optional<EmpresaEntity> empresaExistente = empresaService.obtenerEmpresaPorId(empresa.getId());

            if (empresaExistente.isPresent()) {
                // Si existe, se está actualizando
                EmpresaEntity empresaOriginal = empresaExistente.get();

                // Verificar si el NIT ha cambiado
                if (!empresaOriginal.getId().equals(empresa.getId())) {
                    // Si el NIT cambió, verificar si ya existe otra empresa con el nuevo NIT
                    Optional<EmpresaEntity> empresaConNuevoNit = empresaService.obtenerEmpresaPorId(empresa.getId());

                    if (empresaConNuevoNit.isPresent()) {
                        return "vistas/empresa/form_empresa"; // Volver al formulario con el error
                    }
                }

                // Actualizar la empresa
                empresaService.guardar(empresa);
            } else {
                // Si no existe, crear una nueva empresa
                empresaService.guardar(empresa);
            }
            return "redirect:/empresa/listado-empresas";
        } catch (Exception e) {
            return "vistas/empresa/form_empresa"; // Redirigir al formulario en caso de error
        }
    }


    @GetMapping("/eliminar/{id}")
    public String eliminarEmpresa(@PathVariable Long id) {
        empresaService.eliminarEmpresaPorId(id);
        return "redirect:/empresa/listado-empresas";
    }

    @PostMapping("/editar")
    public String guardarEdicion(@ModelAttribute("empresa") EmpresaEntity empresa) {
        empresaService.guardar(empresa);
        return "redirect:/empresas";
    }

//    @GetMapping("/editar/{id}")
//    public String editarEmpresa(@PathVariable Long id, Model model) {
//        Optional<EmpresaEntity> empresa = empresaService.obtenerEmpresaPorId(id);
//        if (empresa.isPresent()) {
//            model.addAttribute("empresa", empresa.get());
//            model.addAttribute("ciudades", ciudadService.obtenerCiudades());
//            model.addAttribute("tiposEmpresas", tipoEmpresaService.obtenerTiposEmpresa());
//            return "vistas/empresa/form_empresa"; // Reutiliza el mismo formulario
//        }
//        return "redirect:/empresa/listado-empresas";
//    }

//    @GetMapping("/editar/{id}")
//    public String actualizarEmpresa(@PathVariable Long id, EmpresaEntity empresaEditada, Model model) {
//        try {
//            // Obtener la empresa original antes de editar
//            Optional<EmpresaEntity> empresaExistente = empresaService.obtenerEmpresaPorId(id);
//
//            if (empresaExistente.isPresent()) {
//                EmpresaEntity empresaOriginal = empresaExistente.get();
//
//                // Verificar si el NIT ha cambiado
//                if (!empresaOriginal.getId().equals(empresaEditada.getId())) {
//                    // Si el NIT cambió, verificar si ya existe otra empresa con el nuevo NIT
//                    Optional<EmpresaEntity> empresaConNuevoNit = empresaService.obtenerEmpresaPorId(empresaEditada.getId());
//
//                    if (empresaConNuevoNit.isPresent()) {
//                        model.addAttribute("error", "El NIT ingresado ya está en uso.");
//                        return "vistas/empresa/form_empresa"; // Volver al formulario con el error
//                    }
//                }
//
//                // Actualizar los demás atributos de la empresa
//                empresaService.guardar(empresaEditada);
//            }
//            return "redirect:/empresa/listado-empresas";
//        } catch (Exception e) {
//            model.addAttribute("error", "Error al actualizar la empresa.");
//            return "vistas/empresa/form_empresa"; // Redirigir al formulario en caso de error
//        }
//    }


}
