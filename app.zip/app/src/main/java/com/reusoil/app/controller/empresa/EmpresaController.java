package com.reusoil.app.controller.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.services.ciudad.CiudadService;
import com.reusoil.app.services.empresa.EmpresaService;
import com.reusoil.app.services.tipo_empresa.TipoEmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

@RequiredArgsConstructor
@RequestMapping("/empresa")
@Controller
public class EmpresaController {

    private final CiudadService ciudadService;
    private final EmpresaService empresaService;
    private final TipoEmpresaService tipoEmpresaService;

    @PostMapping("/guardar")
    public String crearEmpresa(EmpresaEntity nuevaEmpresa){
        empresaService.guardar(nuevaEmpresa);
        return "redirect:/empresa/listado-empresas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarEmpresa(@PathVariable Long id) {
        empresaService.eliminarEmpresaPorId(id);
        return "redirect:/empresa/listado-empresas";
    }

    @GetMapping("/editar/{id}")
    public String editarEmpresa(@PathVariable Long id, Model model) {
        Optional<EmpresaEntity> empresa = empresaService.obtenerEmpresaPorId(id);
        if (empresa.isPresent()) {
            model.addAttribute("empresa", empresa.get());
            model.addAttribute("ciudades", ciudadService.obtenerCiudades());
            model.addAttribute("tiposEmpresas", tipoEmpresaService.obtenerTiposEmpresa());
            return "vistas/empresa/form_empresa"; // Reutiliza el mismo formulario
        }
        return "redirect:/empresa/listado-empresas";
    }

}
