package com.reusoil.app.models.configuracion;

public class ConfiguracionEntity {
}
