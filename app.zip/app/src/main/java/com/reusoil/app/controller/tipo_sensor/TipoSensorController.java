package com.reusoil.app.controller.tipo_sensor;

import com.reusoil.app.models.tipo_sensor.TipoSensorEntity;
import com.reusoil.app.services.tipo_sensor.TipoSensorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

@Controller
@RequiredArgsConstructor
@RequestMapping("/tipo-sensor")
public class TipoSensorController {

    private final TipoSensorService tipoSensorService;

    // Guarda un nuevo sensor o actualiza uno existente
    @PostMapping("/guardar")
    public String crearOActualizarTipoSensor(@ModelAttribute("tipoSensor") TipoSensorEntity tipoSensor, Model model) {
        try {
            if (tipoSensor.getId() != null && tipoSensorService.obtenerTipoSensorPorId(tipoSensor.getId()).isPresent()) {
                tipoSensorService.guardar(tipoSensor);
            } else {
                tipoSensor.setId(null); // Para asegurarnos de que se crea un nuevo registro si no existe ID
                tipoSensorService.guardar(tipoSensor);
            }
            return "redirect:/tipo-sensor/listado-sensores"; // Redirigimos a la lista correcta
        } catch (Exception e) {
            model.addAttribute("tipoSensor", tipoSensor);
            return "vistas/tipo-sensor/form_tipo-sensor"; // En caso de error, mostrar el formulario de nuevo
        }
    }

    // Guarda los cambios de la edición de un sensor
    @PostMapping("/editar")
    public String guardarEdicion(@ModelAttribute("tipoSensor") TipoSensorEntity tipoSensor) {
        tipoSensorService.guardar(tipoSensor);
        return "redirect:/tipo-sensor/listado-sensores"; // Redirigir a la lista correcta después de editar
    }

    // Eliminar un tipo de sensor
    @GetMapping("/eliminar/{id}")
    public String eliminarTipoSensor(@PathVariable Long id) {
        tipoSensorService.eliminarTipoSensorPorId(id);
        return "redirect:/tipo-sensor/listado-sensores"; // Redirigir después de eliminar
    }
}
