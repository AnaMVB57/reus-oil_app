//package com.reusoil.app.controller.tipo_sensor;
//
//import com.reusoil.app.models.tipo_empresa.TipoEmpresaAPI;
//import com.reusoil.app.models.tipo_sensor.TipoSensorAPI;
//import com.reusoil.app.models.tipo_sensor.TipoSensorEntity;
//import com.reusoil.app.services.tipo_sensor.TipoSensorService;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.ui.Model;
//
//import java.util.List;
//
//@Controller
//@RequestMapping("/tipo-sensor")
//public class TipoSensorController {
//
//    private final TipoSensorService tipoSensorService;
//
//    public TipoSensorController(TipoSensorService tipoSensorService) {
//        this.tipoSensorService = tipoSensorService;
//    }
//
//    @GetMapping("/nuevo-tipo-sensor")
//    public String mostrarFormularioEmpresa(Model model) {
//        model.addAttribute("tipo-sensor", new TipoSensorAPI());
//        return "vistas/tipo-sensor/form_tipo-sensor";
//    }
//
////    @PostMapping("/registrar")
////    public String registrarTipoSensor(@ModelAttribute TipoSensorEntity tipoSensor) {
////        tipoSensorService.save(tipoSensor);
////        return "redirect:/tipo-sensor/";
////    }
////
////    @GetMapping("/{id}")
////    public TipoSensorEntity obtenerTipoSensor(@PathVariable Long id) {
////        return tipoSensorService.findById(id).orElse(null);
////    }
////
////    @PutMapping("/actualizar")
////    public TipoSensorEntity actualizarTipoSensor(@RequestBody TipoSensorEntity tipoSensor) {
////        return tipoSensorService.save(tipoSensor);
////    }
////
////    @DeleteMapping("/eliminar/{id}")
////    public String eliminarTipoSensor(@PathVariable Long id) {
////        tipoSensorService.deleteById(id);
////        return "redirect:/tipo-sensor/";
////    }
////
////    @GetMapping("/todos")
////    public String obtenerTodosLosTiposDeSensor(Model model) {
////        List<TipoSensorEntity> sensores = tipoSensorService.findAll();
////        model.addAttribute("sensores", sensores);
////        return "";
////    }
//}
