package com.reusoil.app.models.ciudad;

public class CiudadAPI {
}
