package com.reusoil.app.controller.perfil;

import com.reusoil.app.models.perfil.PerfilEntity;
import com.reusoil.app.services.perfil.PerfilService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RequestMapping("/perfil")
@Controller
public class PerfilController {

    private final PerfilService perfilService;

    // Mostrar formulario para crear un nuevo perfil
    @GetMapping("/guardar")
    public String mostrarFormularioCrearPerfil(Model model) {
        model.addAttribute("perfilEntity", new PerfilEntity()); // Crea una nueva instancia
        return "vistas/perfil/form_perfil"; // Asegúrate de que esta ruta sea correcta
    }

    // Guarda la información que se le envía por el formulario
    @PostMapping("/guardar")
    public String crearPerfil(@ModelAttribute PerfilEntity nuevoPerfil) {
        perfilService.guardar(nuevoPerfil);
        return "redirect:/perfil/listado"; // Redirige al listado de perfiles después de guardar
    }
}
