package com.reusoil.app.controller.perfil;

import com.reusoil.app.models.perfil.PerfilEntity;
import com.reusoil.app.services.perfil.PerfilService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RequestMapping("/perfil")
@Controller
public class PerfilController {

    private final PerfilService perfilService;

    @PostMapping("/guardar")
    public String crearOActualizarPerfil(@Valid @ModelAttribute("perfil") PerfilEntity perfil,
                                         BindingResult bindingResult,
                                         Model model) {
        // Verificar errores de validación
        if (bindingResult.hasErrors()) {
            model.addAttribute("error", "Por favor, corrija los errores en el formulario");
            return "vistas/perfil/form_perfil"; // Volver al formulario con errores de validación
        }

        perfilService.guardar(perfil);
        return "redirect:/perfil/listado-perfiles";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarPerfil(@PathVariable Long id) {
        perfilService.borradoLogico(id);
        return "redirect:/perfil/listado-perfiles";
    }

    // Método para listar perfiles según su estado
    @GetMapping("/listado-perfiles/{estado}")
    public String listarPerfilesPorEstado(@PathVariable boolean estado, Model model) {
        List<PerfilEntity> perfiles = perfilService.obtenerPerfilesPorEstado(estado);
        model.addAttribute("perfiles", perfiles);
        return "vistas/perfil/listado_perfiles"; // Asegúrate de tener esta vista
    }
}
