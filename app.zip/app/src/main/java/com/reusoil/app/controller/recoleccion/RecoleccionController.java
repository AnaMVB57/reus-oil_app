package com.reusoil.app.controller.recoleccion;

import com.reusoil.app.models.recoleccion.RecoleccionEntity;
import com.reusoil.app.services.recoleccion.RecoleccionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RequestMapping("/recoleccion")
@Controller
public class RecoleccionController {

    private final RecoleccionService recoleccionService;

    @PostMapping("/guardar")
    public String crearOActualizarRecoleccion(@Valid @ModelAttribute("recoleccion") RecoleccionEntity recoleccion,
                                              BindingResult bindingResult,
                                              Model model) {
        // Verificar errores de validación
        if (bindingResult.hasErrors()) {
            model.addAttribute("error", "Por favor, corrija los errores en el formulario");
            return "vistas/recoleccion/form_recoleccion"; // Volver al formulario con errores de validación
        }

        recoleccionService.guardar(recoleccion);
        return "redirect:/recoleccion/listado-recolecciones"; // Redirigir al listado de recolecciones
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarRecoleccion(@PathVariable Long id) {
        recoleccionService.borradoLogico(id);
        return "redirect:/recoleccion/listado-recolecciones"; // Redirigir al listado de recolecciones
    }

    // Método para listar recolecciones según su estado
    @GetMapping("/listado-recolecciones/{estado}")
    public String listarRecoleccionesPorEstado(@PathVariable boolean estado, Model model) {
        List<RecoleccionEntity> recolecciones = recoleccionService.obtenerPorEstado(estado); // Cambiado aquí
        model.addAttribute("recolecciones", recolecciones);
        return "vistas/recoleccion/listado_recolecciones"; // Asegúrate de tener esta vista
    }
}
