package com.reusoil.app.models.ciudad;

import com.reusoil.app.models.empresa.EmpresaEntity;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity(name = "ciudad")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CiudadEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private boolean estado;

    @OneToMany(mappedBy = "ciudad", cascade = CascadeType.PERSIST)
    private List<EmpresaEntity> empresas;

}
