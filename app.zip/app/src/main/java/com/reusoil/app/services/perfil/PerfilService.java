package com.reusoil.app.services.perfil;

import com.reusoil.app.models.perfil.PerfilEntity;

import java.util.List;
import java.util.Optional;

public interface PerfilService {
    List<PerfilEntity> obtenerPerfiles();
    Optional<PerfilEntity> obtenerPerfilPorId(Long id);
    void guardar(PerfilEntity perfil);
    void eliminarPerfilPorId(Long id); // Este es el método que estás usando en el controlador
}
