package com.reusoil.app.repository.tipo_sensor;

public interface Tipo_SensorDAOIface {
}
