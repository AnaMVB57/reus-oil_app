package com.reusoil.app.controller.contenedor;

import com.reusoil.app.models.contenedor.ContenedorEntity;
import com.reusoil.app.services.contendor.ContenedorService;
import com.reusoil.app.services.empresa.EmpresaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RequiredArgsConstructor
@Controller
@RequestMapping("/contenedor")
public class ContenedorVistaController {

    private final ContenedorService contenedorService;
    private final EmpresaService empresaService;

    // Mostrar formulario para crear un nuevo contenedor
    @GetMapping("/guardar-contenedor")
    public String mostrarFormularioContenedor(Model model) {
        model.addAttribute("modoEdicion", false);
        model.addAttribute("contenedor", new ContenedorEntity());
        model.addAttribute("empresas", empresaService.obtenerEmpresasPorEstado(true));
        return "vistas/contenedor/form_contenedor";
    }

    // Mostrar listado de todos los contenedores
    @GetMapping("/listado-contenedores")
    public String mostrarListadoContenedores(Model model) {
        model.addAttribute("contenedores", contenedorService.obtenerContenedores());
        model.addAttribute("mensaje", "Listado de contenedores");
        return "vistas/contenedor/listado_contenedor";
    }

    // Mostrar formulario para editar un contenedor existente
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable("id") Long id, Model model) {
        Optional<ContenedorEntity> contenedor = contenedorService.obtenerContenedorPorId(id);
        if (contenedor.isPresent()) {
            model.addAttribute("contenedor", contenedor.get());
            model.addAttribute("empresas", empresaService.obtenerEmpresas());
            model.addAttribute("modoEdicion", true); // Indica que se está en modo de edición
            return "vistas/contenedor/form_contenedor"; // Reutiliza el mismo formulario para edición
        }
        return "redirect:/contenedor/listado_contenedor"; // Redirige si no se encuentra el contenedor
    }
}
