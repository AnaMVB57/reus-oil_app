//package com.reusoil.app.models.tipo_sensor;
//
//public class TipoSensorAPI {
//}
//
