package com.reusoil.app.models.tipo_sensor;

import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TipoSensorAPI {

    private Long id;

}

