package com.reusoil.app.services.tipo_empresa;

public class Tipo_EmpresaService {
}
