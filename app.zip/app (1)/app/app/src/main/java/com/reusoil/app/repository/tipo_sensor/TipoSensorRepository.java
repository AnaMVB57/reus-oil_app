//package com.reusoil.app.repository.tipo_sensor;
//
//import com.reusoil.app.models.tipo_sensor.TipoSensorEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface TipoSensorRepository extends JpaRepository<TipoSensorEntity, Long> {
//}
