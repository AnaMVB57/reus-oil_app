package com.reusoil.app.services.empresa;

import com.reusoil.app.models.empresa.EmpresaEntity;
import com.reusoil.app.models.usuario.UsuarioEntity;
import com.reusoil.app.repository.empresa.EmpresaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class EmpresaService {

    final private EmpresaRepository empresaRepository;

    public EmpresaService(EmpresaRepository empresaRepository){
        this.empresaRepository = empresaRepository;
    }

    @Transactional(readOnly = true)
    public List<EmpresaEntity> findAll() {
        return empresaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<EmpresaEntity> findById(Long id) {
        return empresaRepository.findById(id);
    }

    @Transactional
    public EmpresaEntity save(EmpresaEntity empresa) {
        return empresaRepository.save(empresa);
    }
    @Transactional
    public void deleteById(Long id) {
        empresaRepository.deleteById(id);
    }
}
